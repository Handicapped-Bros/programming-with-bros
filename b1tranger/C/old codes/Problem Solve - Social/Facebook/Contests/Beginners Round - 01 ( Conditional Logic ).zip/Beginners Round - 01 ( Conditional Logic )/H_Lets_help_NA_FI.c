#include<stdio.h>

int main()

{
    int a,b,c,x,y,z; //x,y,z is position holders
    scanf("%d%d%d",&a,&b,&c);
    if(a>b && a>c)
    {
        x=a;
        if(b>c)
        {
            y=b,z=c;
        }
        else
        {
            y=c,z=b;
        }
    }

    else if(b>a && b>c)
    {
        x=b;
        if(a>c)
        {
            y=a,z=c;
        }
        else
        {
            y=c,z=a;
        }
    }
    else if(c>a && c>b)
    {
        x=c;
        if(b>a)
        {
            y=b,z=a;
        }
        else
        {
            y=a,z=b;
        }
    }
    printf("%d %d %d\n",z,y,x);

    return 0;
}

/*
Write a program which reads three integers, and prints them in ascending order.

Input
Three integers separated by a single space are given in a line.

Output
Print the given integers in ascending order in a line. Put a single space between two integers.

Constraints
1 ≤ the three integers ≤ 10000
Sample Input 1
3 8 1
Sample Output 1
1 3 8

*/