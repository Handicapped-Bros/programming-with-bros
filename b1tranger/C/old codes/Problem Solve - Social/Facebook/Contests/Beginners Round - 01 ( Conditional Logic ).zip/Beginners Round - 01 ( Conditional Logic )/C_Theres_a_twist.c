#include<stdio.h>

int main()

{
    int A,B;
    scanf("%d%d",&A,&B);
    if(A>=1 && A<=9 && B>=1 && B<=9)
    {
        printf("%d", A*B);
    }
    else if(A>=1 && A<=20 && B>=1 && B<=20)
    {
        printf("-1");
    }

    return 0;
}
/*
Alice and Bob are playing a game and each one of them has a score.

Alice got a score n
 and Bob got a score m
, the one who has a maximum score will win

find who will win this game

Input
you are giving two number n,m
 (1≤n,m≤1012
).

n
 is the Alice score

m
 is the Bob score

Output
print "Alice win" (without quotes) if he got the maximum score

print "Bob win" (without quotes) if he got the maximum score

if Alice and Bob got the same score print "Draw" (without quotes)

Sample 1
Inputcopy	Outputcopy
30 27
Alice win
Sample 2
Inputcopy	Outputcopy
15 21
Bob win
Sample 3
Inputcopy	Outputcopy
10 10
Draw

*/