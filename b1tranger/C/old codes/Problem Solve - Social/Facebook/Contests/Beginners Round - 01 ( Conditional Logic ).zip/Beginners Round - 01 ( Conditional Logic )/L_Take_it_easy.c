#include<stdio.h>

int main()

{
int a,b,c,x,y,z;
scanf("%d%d%d",&a,&b,&c);
if(a>b && a>c)
    {
        x=a;
        if(b>c)
        {
            y=b,z=c;
        }
        else
        {
            y=c,z=b;
        }
    }

    else if(b>a && b>c)
    {
        x=b;
        if(a>c)
        {
            y=a,z=c;
        }
        else
        {
            y=c,z=a;
        }
    }
    else if(c>a && c>b)
    {
        x=c;
        if(b>a)
        {
            y=b,z=a;
        }
        else
        {
            y=a,z=b;
        }
    }

printf("%d\n",y+z);
    return 0;
}

/*
Problem Statement
Snuke is buying a bicycle. The bicycle of his choice does not come with a bell, so he has to buy one separately.

He has very high awareness of safety, and decides to buy two bells, one for each hand.

The store sells three kinds of bells for the price of 
�
a, 
�
b and 
�
c yen (the currency of Japan), respectively. Find the minimum total price of two different bells.

Constraints
1
≤
�
,
�
,
�
≤
10000
1≤a,b,c≤10000
�
a, 
�
b and 
�
c are integers.
Input
Input is given from Standard Input in the following format:

�
a 
�
b 
�
c
Output
Print the minimum total price of two different bells.

Sample 1
Inputcopy	Outputcopy
700 600 780
1300
Buying a 
700
700-yen bell and a 
600
600-yen bell costs 
1300
1300 yen.
Buying a 
700
700-yen bell and a 
780
780-yen bell costs 
1480
1480 yen.
Buying a 
600
600-yen bell and a 
780
780-yen bell costs 
1380
1380 yen.
The minimum among these is 
1300
1300 yen.

Sample 2
Inputcopy	Outputcopy
10000 10000 10000
20000
Buying any two bells costs 
20000
20000 yen

*/
