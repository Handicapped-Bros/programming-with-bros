#include<stdio.h>

int main()

{
    int S,W;
    scanf("%d%d",&S,&W);

    if(W>S || W==S)
    {
        printf("unsafe");
    }
    else
    {
        printf("safe");
    }



    return 0;
}

/*
Problem Statement
There are 
�
S sheep and 
�
W wolves.

If the number of wolves is greater than or equal to that of sheep, the wolves will attack the sheep.

If the wolves will attack the sheep, print unsafe; otherwise, print safe.

Constraints
1
≤
�
≤
100
1≤S≤100
1
≤
�
≤
100
1≤W≤100
Input
Input is given from Standard Input in the following format:

�
S 
�
W
Output
If the wolves will attack the sheep, print unsafe; otherwise, print safe.

Sample 1
Inputcopy	Outputcopy
4 5
unsafe
There are four sheep and five wolves. The number of wolves is not less than that of sheep, so they will attack them.

Sample 2
Inputcopy	Outputcopy
100 2
safe
Many a sheep drive away two wolves.

Sample 3
Inputcopy	Outputcopy
10 10
unsafe

*/
