#include<stdio.h>

int main()

{
    long long A,B,C,D,X;
    scanf("%lld%lld%lld%lld",&A,&B,&C,&D);
    X = (A*B)-(C*D);
    printf("Difference = %lld",X);



    return 0;
}

/*
Given four numbers A, B, C and D. Print the result of the following equation :

 X = (A * B) - (C * D).

Input
Only one line containing 4 separated numbers A, B, C and D ( - 105  ≤  A, B, C, D  ≤  105).

Output
Print "Difference  =  " without quotes followed by the equation result.

Sample 1
Inputcopy	Outputcopy
1 2 3 4
Difference = -10
Sample 2
Inputcopy	Outputcopy
2 3 4 5
Difference = -14
Sample 3
Inputcopy	Outputcopy
4 5 2 3
Difference = 14


*/
