#include<stdio.h>

int main()

{
    int n;
    scanf("%d", &n);
    if(n==10)
    {
        printf("YES");
    }
    else
    {
        printf("NO");
    }

    return 0;
}


/*
You are giving integer n
 you need to find if the number n=10
 or not

Input
The only line contains one integer n
 (1≤n≤100
)

Output
print YES if n=10

otherwise print NO

Sample 1
Inputcopy	Outputcopy
5
NO
Sample 2
Inputcopy	Outputcopy
3
NO
Sample 3
Inputcopy	Outputcopy
10
YES

*/